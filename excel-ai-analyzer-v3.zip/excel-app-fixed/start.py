#!/usr/bin/env python3
"""
Excel AI Analyzer - Auto Start Script
"""

import os
import sys
import subprocess
import shutil

def print_banner():
    print("=" * 50)
    print("     Excel AI Analyzer - Starting Up")
    print("=" * 50)
    print()

def check_python():
    print("[INFO] Checking Python installation...")
    try:
        result = subprocess.run([sys.executable, "--version"], capture_output=True, text=True, check=True)
        print(f"[OK] {result.stdout.strip()}")
        return True
    except Exception as e:
        print(f"[ERROR] Python check failed: {e}")
        return False

def install_no_venv():
    """Install packages directly using system Python"""
    print("[INFO] Installing packages directly (no virtual environment)...")
    packages = ["flask", "pandas", "openpyxl", "google-generativeai", "werkzeug", "requests"]
    for pkg in packages:
        try:
            print(f"  Installing {pkg}...")
            subprocess.run([sys.executable, "-m", "pip", "install", pkg], check=False)
        except Exception as e:
            print(f"  [WARN] {pkg}: {e}")
    return True

def start_app():
    print()
    print("=" * 50)
    print("     Starting Excel AI Analyzer")
    print("     Open browser: http://localhost:5000")
    print("=" * 50)
    print()
    try:
        subprocess.run([sys.executable, "app.py"])
    except KeyboardInterrupt:
        print("\n[INFO] Shutting down...")
    except Exception as e:
        print(f"[ERROR] Failed to start app: {e}")
        input("Press Enter to exit...")

def main():
    print_banner()
    if not check_python():
        input("Press Enter to exit...")
        return
    print()
    install_no_venv()
    start_app()

if __name__ == "__main__":
    main()
