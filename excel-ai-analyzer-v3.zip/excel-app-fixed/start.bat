@echo off
echo ==========================================
echo     Excel AI Analyzer - Starting Up
echo ==========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH
    pause
    exit /b 1
)

echo [OK] Python found
echo.

REM ALWAYS delete and recreate venv to avoid corruption
echo [INFO] Preparing clean environment...
if exist "venv" (
    rmdir /s /q venv
    echo [OK] Removed old environment
)

echo [INFO] Creating virtual environment...
python -m venv venv --without-pip
if errorlevel 1 (
    echo [ERROR] Failed to create virtual environment
    pause
    exit /b 1
)

echo [OK] Virtual environment created
echo.

REM Download get-pip.py and install pip manually
echo [INFO] Installing pip...
curl -sS https://bootstrap.pypa.io/get-pip.py -o get-pip.py >nul 2>&1
if not exist "get-pip.py" (
    powershell -Command "Invoke-WebRequest -Uri https://bootstrap.pypa.io/get-pip.py -OutFile get-pip.py" >nul 2>&1
)

venv\Scripts\python.exe get-pip.py --no-setuptools --no-wheel >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Could not install pip via get-pip.py, trying alternative...
    python -m pip install --target=venv\Lib\site-packages pip >nul 2>&1
)

REM Clean up
if exist "get-pip.py" del get-pip.py

echo [INFO] Installing dependencies...
venv\Scripts\python.exe -m pip install flask pandas openpyxl google-generativeai werkzeug requests

echo.
echo ==========================================
echo     Starting Excel AI Analyzer
echo     Open browser: http://localhost:5000
echo ==========================================
echo.

venv\Scripts\python.exe app.py

pause
