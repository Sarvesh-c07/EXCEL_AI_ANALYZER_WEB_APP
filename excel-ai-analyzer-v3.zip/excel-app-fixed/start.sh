#!/bin/bash

echo "=========================================="
echo "     Excel AI Analyzer - Starting Up"
echo "=========================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 is not installed"
    read -p "Press Enter to exit..."
    exit 1
fi

echo "[OK] Python3 found"
echo ""

# Check if venv exists but is broken
if [ -d "venv" ]; then
    echo "[INFO] Checking virtual environment..."
    if ! venv/bin/python --version &> /dev/null; then
        echo "[WARNING] Virtual environment is corrupted. Recreating..."
        rm -rf venv
    else
        echo "[OK] Virtual environment looks good"
    fi
fi

# Create virtual environment if not exists
if [ ! -d "venv" ]; then
    echo "[INFO] Creating virtual environment..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to create virtual environment"
        read -p "Press Enter to exit..."
        exit 1
    fi
    echo "[OK] Virtual environment created"
fi

# Ensure pip works
echo "[INFO] Setting up pip..."
venv/bin/python -m ensurepip --upgrade &> /dev/null
venv/bin/python -m pip install --upgrade pip setuptools wheel

echo "[INFO] Installing dependencies..."
venv/bin/python -m pip install flask pandas openpyxl google-generativeai werkzeug

echo ""
echo "=========================================="
echo "     Starting Excel AI Analyzer"
echo "     Open browser: http://localhost:5000"
echo "=========================================="
echo ""

venv/bin/python app.py
read -p "Press Enter to exit..."
