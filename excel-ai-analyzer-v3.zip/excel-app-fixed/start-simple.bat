@echo off
echo ==========================================
echo     Excel AI Analyzer - Starting Up
echo ==========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH
    pause
    exit /b 1
)

echo [OK] Python found
echo.

echo [INFO] Installing dependencies directly...
python -m pip install flask pandas openpyxl google-generativeai werkzeug requests

echo.
echo ==========================================
echo     Starting Excel AI Analyzer
echo     Open browser: http://localhost:5000
echo ==========================================
echo.

python app.py

pause
