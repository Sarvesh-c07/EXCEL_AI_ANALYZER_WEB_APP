/**
 * DataLens AI — Main Application JS
 * Features: multi-table results, dashboard charts, per-table switcher
 */

// ===== STATE =====
let uploadedFiles = [];
let currentResult = null;
let recognition = null;
let isRecording = false;
let activeTableKey = null;
let activeDashKey = null;
let tableCharts = {}; // store chart instances per table key

// ===== DOM REFS =====
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const filesList = document.getElementById('filesList');
const queryInput = document.getElementById('queryInput');
const sendQuery = document.getElementById('sendQuery');
const micBtn = document.getElementById('micBtn');
const voiceWave = document.getElementById('voiceWave');
const voiceStatus = document.getElementById('voiceStatus');
const voiceResult = document.getElementById('voiceResult');
const textQueryWrapper = document.getElementById('textQueryWrapper');
const voiceQueryWrapper = document.getElementById('voiceQueryWrapper');
const modeBtns = document.querySelectorAll('.mode-btn');
const resultsSection = document.getElementById('resultsSection');
const emptyState = document.getElementById('emptyState');
const loadingState = document.getElementById('loadingState');
const loadingApi = document.getElementById('loadingApi');
const downloadBtn = document.getElementById('downloadBtn');
const insightsBanner = document.getElementById('insightsBanner');
const insightsText = document.getElementById('insightsText');
const apiBadge = document.getElementById('apiBadge');
const apiStatus = document.getElementById('apiStatusBar');
const apiIndicator = document.getElementById('apiIndicator');
const tableSwitcher = document.getElementById('tableSwitcher');
const switcherTabs = document.getElementById('switcherTabs');
const tablePanels = document.getElementById('tablePanels');
const dashboardSection = document.getElementById('dashboardSection');
const dashSwitcher = document.getElementById('dashSwitcher');
const dashSwitchTabs = document.getElementById('dashSwitchTabs');
const dashboardPanels = document.getElementById('dashboardPanels');
const analysisSummary = document.getElementById('analysisSummary');
const headerStats = document.getElementById('headerStats');
const statFiles = document.getElementById('statFiles');
const statRows = document.getElementById('statRows');
const statCols = document.getElementById('statCols');
const previewPanelWrap = document.getElementById('previewPanelWrap');
const previewContent = document.getElementById('previewContent');
const clearAllBtn = document.getElementById('clearAllBtn');

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    initSpeechRecognition();
    loadSavedApiKeys();
    updateApiStatus();
    autoResizeTextarea();
});

// ===== API KEYS =====
function loadSavedApiKeys() {
    document.getElementById('geminiKey').value = localStorage.getItem('gemini_api_key') || '';
    document.getElementById('groqKey').value = localStorage.getItem('groq_api_key') || '';
    document.getElementById('openrouterKey').value = localStorage.getItem('openrouter_api_key') || '';
}
function saveApiKeys() {
    localStorage.setItem('gemini_api_key', document.getElementById('geminiKey').value);
    localStorage.setItem('groq_api_key', document.getElementById('groqKey').value);
    localStorage.setItem('openrouter_api_key', document.getElementById('openrouterKey').value);
}
['geminiKey','groqKey','openrouterKey'].forEach(id => {
    document.getElementById(id).addEventListener('input', () => { saveApiKeys(); updateApiStatus(); });
});
function updateApiStatus() {
    const g = document.getElementById('geminiKey').value.trim().length > 0;
    const gr = document.getElementById('groqKey').value.trim().length > 0;
    const or = document.getElementById('openrouterKey').value.trim().length > 0;
    const total = g + gr + or;
    const names = [];
    if (g) names.push('Gemini');
    if (gr) names.push('Groq');
    if (or) names.push('OpenRouter');
    const dot = apiStatus.querySelector('.status-dot');
    const txt = apiStatus.querySelector('span:last-child');
    const idot = apiIndicator.querySelector('.indicator-dot');
    const itxt = apiIndicator.querySelector('.indicator-text');
    if (total === 0) {
        dot.className = 'status-dot offline'; txt.textContent = 'No API — local processing only';
        idot.className = 'indicator-dot offline'; itxt.textContent = 'No API';
    } else {
        dot.className = 'status-dot online'; txt.textContent = `${total} API(s) ready: ${names.join(', ')}`;
        idot.className = 'indicator-dot online'; itxt.textContent = names.join(', ');
    }
}

// ===== UPLOAD =====
uploadArea.addEventListener('click', () => fileInput.click());
uploadArea.addEventListener('dragover', e => { e.preventDefault(); uploadArea.classList.add('dragover'); });
uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('dragover'));
uploadArea.addEventListener('drop', e => { e.preventDefault(); uploadArea.classList.remove('dragover'); handleFiles(e.dataTransfer.files); });
fileInput.addEventListener('change', e => handleFiles(e.target.files));

function handleFiles(files) {
    const valid = Array.from(files).filter(f => /\.(xlsx|xls|csv)$/i.test(f.name));
    if (!valid.length) { showToast('Please upload Excel (.xlsx, .xls) or CSV files', 'error'); return; }
    uploadFilesToServer(valid);
}

async function uploadFilesToServer(files) {
    const formData = new FormData();
    files.forEach(f => formData.append('files', f));
    showToast('Uploading files...', 'info');
    try {
        const response = await fetch('/upload', { method: 'POST', body: formData });
        const contentType = response.headers.get('content-type');
        if (!contentType?.includes('application/json')) { showToast('Server error', 'error'); return; }
        const data = await response.json();
        if (data.success) {
            uploadedFiles = data.files;
            renderFilesList(data.schema);
            updateHeaderStats(data.schema);
            showToast(data.message, 'success');
            clearAllBtn.style.display = '';
        } else {
            showToast(data.error || 'Upload failed', 'error');
        }
    } catch (e) {
        showToast('Error uploading: ' + e.message, 'error');
    }
}

function getFileIcon(filename) {
    const ext = filename.split('.').pop().toLowerCase();
    if (ext === 'csv') return { cls: 'csv', icon: 'fa-file-csv' };
    if (ext === 'xlsx') return { cls: 'xlsx', icon: 'fa-file-excel' };
    return { cls: 'default', icon: 'fa-file-spreadsheet' };
}

function renderFilesList(schema) {
    filesList.innerHTML = uploadedFiles.map((file, i) => {
        const { cls, icon } = getFileIcon(file);
        const meta = schema?.[file];
        const shape = meta ? `${meta.shape[0]} rows × ${meta.shape[1]} cols` : '';
        return `
        <div class="file-item" data-file="${file}">
            <div class="file-icon ${cls}"><i class="fas ${icon}"></i></div>
            <div class="file-meta">
                <div class="file-name">${file}</div>
                <div class="file-size">${shape}</div>
            </div>
            <div class="file-actions">
                <button class="file-btn" onclick="previewFile('${file}')" title="Preview"><i class="fas fa-eye"></i></button>
                <button class="file-btn danger" onclick="removeFile(${i})" title="Remove"><i class="fas fa-xmark"></i></button>
            </div>
        </div>`;
    }).join('');
}

function updateHeaderStats(schema) {
    if (!schema) return;
    const files = Object.keys(schema);
    let totalRows = 0, totalCols = 0;
    files.forEach(f => { totalRows += schema[f].shape[0]; totalCols = Math.max(totalCols, schema[f].shape[1]); });
    statFiles.textContent = files.length;
    statRows.textContent = totalRows.toLocaleString();
    statCols.textContent = totalCols;
    headerStats.style.display = '';
}

async function previewFile(filename) {
    try {
        const response = await fetch('/preview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ filename }) });
        const data = await response.json();
        if (data.error) { showToast(data.error, 'error'); return; }
        previewPanelWrap.style.display = '';
        let html = `<div class="preview-meta">${data.shape[0]} rows × ${data.shape[1]} columns</div>
        <div class="table-scroll"><table class="preview-table"><thead><tr>`;
        data.columns.forEach(c => { html += `<th>${c}</th>`; });
        html += '</tr></thead><tbody>';
        data.preview.forEach(row => {
            html += '<tr>';
            data.columns.forEach(c => { html += `<td>${row[c] ?? ''}</td>`; });
            html += '</tr>';
        });
        html += '</tbody></table></div>';
        previewContent.innerHTML = html;
    } catch (e) { showToast('Error previewing file', 'error'); }
}

function removeFile(index) {
    uploadedFiles.splice(index, 1);
    renderFilesList();
    if (!uploadedFiles.length) {
        previewPanelWrap.style.display = 'none';
        clearAllBtn.style.display = 'none';
        headerStats.style.display = 'none';
    }
}

clearAllBtn.addEventListener('click', () => {
    uploadedFiles = [];
    filesList.innerHTML = '';
    previewPanelWrap.style.display = 'none';
    clearAllBtn.style.display = 'none';
    headerStats.style.display = 'none';
    resultsSection.style.display = 'none';
    emptyState.style.display = '';
    showToast('All files cleared', 'info');
});

// ===== QUERY MODES =====
modeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        modeBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        if (btn.dataset.mode === 'text') {
            textQueryWrapper.style.display = '';
            voiceQueryWrapper.style.display = 'none';
        } else {
            textQueryWrapper.style.display = 'none';
            voiceQueryWrapper.style.display = '';
        }
    });
});

// Quick queries
document.querySelectorAll('.qq-tag').forEach(tag => {
    tag.addEventListener('click', () => { queryInput.value = tag.dataset.query; queryInput.focus(); });
});

// ===== SEND QUERY =====
sendQuery.addEventListener('click', () => {
    const q = queryInput.value.trim();
    if (!q) { showToast('Please enter a query', 'error'); return; }
    if (!uploadedFiles.length) { showToast('Please upload at least one file first', 'error'); return; }
    analyzeData(q);
});
queryInput.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendQuery.click(); } });

function autoResizeTextarea() {
    queryInput.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 150) + 'px';
    });
}

// ===== SPEECH =====
function initSpeechRecognition() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) return;
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SR();
    recognition.continuous = false; recognition.interimResults = true; recognition.lang = 'en-US';
    recognition.onstart = () => { isRecording = true; micBtn.classList.add('recording'); voiceWave.classList.add('active'); voiceStatus.textContent = 'Listening...'; voiceResult.textContent = ''; };
    recognition.onresult = e => { let t = ''; for (let i = e.resultIndex; i < e.results.length; i++) t += e.results[i][0].transcript; voiceResult.textContent = t; };
    recognition.onend = () => {
        isRecording = false; micBtn.classList.remove('recording'); voiceWave.classList.remove('active'); voiceStatus.textContent = 'Tap to start speaking';
        const final = voiceResult.textContent.trim();
        if (final) { queryInput.value = final; modeBtns[0].click(); showToast('Voice captured! Click Analyze.', 'success'); }
    };
    recognition.onerror = e => { isRecording = false; micBtn.classList.remove('recording'); voiceWave.classList.remove('active'); voiceStatus.textContent = 'Error: ' + e.error; };
}
micBtn.addEventListener('click', () => {
    if (!recognition) { showToast('Speech recognition not available', 'error'); return; }
    if (!uploadedFiles.length) { showToast('Please upload files first', 'error'); return; }
    if (isRecording) recognition.stop(); else recognition.start();
});

// ===== ANALYZE =====
async function analyzeData(query) {
    emptyState.style.display = 'none';
    resultsSection.style.display = 'none';
    loadingState.style.display = 'flex';
    saveApiKeys();
    try {
        const response = await fetch('/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query,
                gemini_key: document.getElementById('geminiKey').value.trim(),
                groq_key: document.getElementById('groqKey').value.trim(),
                openrouter_key: document.getElementById('openrouterKey').value.trim()
            })
        });
        const contentType = response.headers.get('content-type');
        if (!contentType?.includes('application/json')) {
            loadingState.style.display = 'none'; emptyState.style.display = '';
            showToast('Server error: invalid response', 'error'); return;
        }
        const data = await response.json();
        loadingState.style.display = 'none';
        if (data.error && !data.tables) {
            showToast(data.error, 'error'); emptyState.style.display = ''; return;
        }
        currentResult = data;
        displayResults(data);
        if (data.fallback_notice) showToast(data.fallback_notice, 'warning');
    } catch (e) {
        loadingState.style.display = 'none'; emptyState.style.display = '';
        showToast('Analysis failed: ' + e.message, 'error');
    }
}

// ===== DISPLAY RESULTS =====
function displayResults(data) {
    resultsSection.style.display = '';

    // Header
    const apiUsed = data.api_used || 'Unknown';
    apiBadge.textContent = apiUsed;
    apiBadge.className = 'api-badge' + (apiUsed.includes('local') ? ' local' : '');
    analysisSummary.textContent = data.analysis_summary || 'Analysis complete';

    // Insights
    insightsText.textContent = data.insights || 'No additional insights';
    insightsBanner.style.display = '';

    const tables = data.tables || {};
    const tableKeys = Object.keys(tables);

    if (!tableKeys.length) {
        tablePanels.innerHTML = '<div class="no-chart-msg"><i class="fas fa-database"></i>No results returned</div>';
        dashboardSection.style.display = 'none';
        return;
    }

    // Destroy old charts
    Object.values(tableCharts).forEach(charts => charts.forEach(c => c.destroy()));
    tableCharts = {};

    // Multi-table switcher
    if (tableKeys.length > 1) {
        tableSwitcher.style.display = '';
        switcherTabs.innerHTML = tableKeys.map((k, i) =>
            `<button class="switcher-tab ${i === 0 ? 'active' : ''}" onclick="switchTable('${k}')" data-key="${k}">
                <i class="fas fa-table"></i> ${k}
            </button>`
        ).join('');
    } else {
        tableSwitcher.style.display = 'none';
    }

    // Build table panels
    tablePanels.innerHTML = tableKeys.map((k, i) => {
        const t = tables[k];
        const rows = t.result_data || [];
        const cols = t.columns || [];
        return `
        <div class="table-panel ${i === 0 ? 'active' : ''}" id="tabpanel-${sanitizeId(k)}">
            <div class="table-panel-header">
                <div class="table-panel-title">
                    <span class="fname-badge">${k}</span>
                    <span class="row-count">${t.total_rows || rows.length} rows</span>
                    <span class="table-panel-insight">${t.table_insight || ''}</span>
                </div>
                <button class="btn-download-table" onclick="downloadTable('${k}')">
                    <i class="fas fa-download"></i> Export
                </button>
            </div>
            <div class="table-scroll-wrap">
                <div class="table-scroll">
                    ${buildTableHTML(cols, rows)}
                </div>
            </div>
        </div>`;
    }).join('');

    activeTableKey = tableKeys[0];

    // Dashboard
    dashboardSection.style.display = '';
    if (tableKeys.length > 1) {
        dashSwitcher.style.display = '';
        dashSwitchTabs.innerHTML = tableKeys.map((k, i) =>
            `<button class="dash-tab ${i === 0 ? 'active' : ''}" onclick="switchDash('${k}')" data-key="${k}">${k}</button>`
        ).join('');
    } else {
        dashSwitcher.style.display = 'none';
    }

    dashboardPanels.innerHTML = tableKeys.map((k, i) => {
        return `<div class="dashboard-panel ${i === 0 ? 'active' : ''}" id="dashpanel-${sanitizeId(k)}"></div>`;
    }).join('');

    activeDashKey = tableKeys[0];

    // Build dashboards
    tableKeys.forEach((k, i) => {
        const t = tables[k];
        setTimeout(() => buildDashboard(k, t), i * 50);
    });
}

function buildTableHTML(cols, rows) {
    if (!cols.length || !rows.length) return '<div class="no-chart-msg" style="padding:2rem;text-align:center;">No data returned</div>';
    let html = `<table class="results-table"><thead><tr>`;
    cols.forEach(c => { html += `<th>${c}</th>`; });
    html += '</tr></thead><tbody>';
    rows.forEach(row => {
        html += '<tr>';
        cols.forEach(c => {
            const v = row[c];
            const isNum = typeof v === 'number' || (typeof v === 'string' && !isNaN(v) && v.trim() !== '');
            html += `<td class="${isNum ? 'num' : ''}">${v !== null && v !== undefined ? v : ''}</td>`;
        });
        html += '</tr>';
    });
    html += '</tbody></table>';
    return html;
}

function sanitizeId(str) { return str.replace(/[^a-zA-Z0-9]/g, '_'); }

function switchTable(key) {
    document.querySelectorAll('.switcher-tab').forEach(t => t.classList.toggle('active', t.dataset.key === key));
    document.querySelectorAll('.table-panel').forEach(p => p.classList.toggle('active', p.id === `tabpanel-${sanitizeId(key)}`));
    activeTableKey = key;
}

function switchDash(key) {
    document.querySelectorAll('.dash-tab').forEach(t => t.classList.toggle('active', t.dataset.key === key));
    document.querySelectorAll('.dashboard-panel').forEach(p => p.classList.toggle('active', p.id === `dashpanel-${sanitizeId(key)}`));
    activeDashKey = key;
}

// ===== DASHBOARD BUILDER =====
function buildDashboard(key, tableData) {
    const container = document.getElementById(`dashpanel-${sanitizeId(key)}`);
    if (!container) return;
    const rows = tableData.result_data || [];
    const cols = tableData.columns || [];
    if (!rows.length) {
        container.innerHTML = '<div class="no-chart-msg"><i class="fas fa-chart-bar"></i>No data to visualize</div>';
        return;
    }

    const numericCols = cols.filter(c => rows.some(r => typeof r[c] === 'number' || (!isNaN(parseFloat(r[c])) && r[c] !== null && r[c] !== '')));
    const textCols = cols.filter(c => !numericCols.includes(c));

    // Stats cards
    let statsHtml = '<div class="stats-row">';
    const colors = ['royal', 'gold', 'emerald', 'violet'];
    numericCols.slice(0, 4).forEach((col, i) => {
        const vals = rows.map(r => parseFloat(r[col]) || 0);
        const sum = vals.reduce((a, b) => a + b, 0);
        const avg = sum / vals.length;
        const max = Math.max(...vals);
        statsHtml += `
        <div class="stat-card ${colors[i]}">
            <div class="stat-card-label">${col}</div>
            <div class="stat-card-value">${formatNum(sum)}</div>
            <div class="stat-card-sub">Avg: ${formatNum(avg)} · Max: ${formatNum(max)}</div>
        </div>`;
    });
    if (!numericCols.length) {
        statsHtml += `<div class="stat-card royal"><div class="stat-card-label">Records</div><div class="stat-card-value">${rows.length}</div><div class="stat-card-sub">${cols.length} columns</div></div>`;
    }
    statsHtml += '</div>';

    // Charts
    let chartsHtml = '<div class="charts-grid">';
    if (numericCols.length && textCols.length) {
        chartsHtml += `<div class="chart-card"><div class="chart-card-header"><i class="fas fa-chart-bar"></i><h4>${textCols[0]} vs ${numericCols[0]}</h4></div><canvas id="chart-bar-${sanitizeId(key)}"></canvas></div>`;
    }
    if (numericCols.length >= 2) {
        chartsHtml += `<div class="chart-card"><div class="chart-card-header"><i class="fas fa-chart-line"></i><h4>${numericCols[0]} Trend</h4></div><canvas id="chart-line-${sanitizeId(key)}"></canvas></div>`;
    }
    if (textCols.length && numericCols.length) {
        chartsHtml += `<div class="chart-card"><div class="chart-card-header"><i class="fas fa-chart-pie"></i><h4>${numericCols[0]} Distribution</h4></div><canvas id="chart-pie-${sanitizeId(key)}"></canvas></div>`;
    }
    if (numericCols.length >= 2) {
        chartsHtml += `<div class="chart-card"><div class="chart-card-header"><i class="fas fa-chart-scatter"></i><h4>${numericCols[0]} vs ${numericCols[1]}</h4></div><canvas id="chart-scatter-${sanitizeId(key)}"></canvas></div>`;
    }
    if (chartsHtml === '<div class="charts-grid">') {
        chartsHtml += `<div class="no-chart-msg"><i class="fas fa-chart-bar"></i>Need numeric columns to generate charts</div>`;
    }
    chartsHtml += '</div>';

    container.innerHTML = statsHtml + chartsHtml;

    // Chart palette
    const palette = ['#7C3FCC','#F59E0B','#10B981','#F43F5E','#0EA5E9','#C084FC','#EC4899','#14B8A6'];

    const chartInstances = [];

    // Bar chart
    const barEl = document.getElementById(`chart-bar-${sanitizeId(key)}`);
    if (barEl && textCols.length && numericCols.length) {
        const labels = rows.slice(0, 12).map(r => String(r[textCols[0]] ?? '').slice(0, 20));
        const values = rows.slice(0, 12).map(r => parseFloat(r[numericCols[0]]) || 0);
        chartInstances.push(new Chart(barEl, {
            type: 'bar',
            data: { labels, datasets: [{ label: numericCols[0], data: values, backgroundColor: palette, borderRadius: 6 }] },
            options: chartOptions('bar', numericCols[0])
        }));
    }

    // Line chart
    const lineEl = document.getElementById(`chart-line-${sanitizeId(key)}`);
    if (lineEl && numericCols.length >= 2) {
        const labels = rows.map((_, i) => i + 1);
        chartInstances.push(new Chart(lineEl, {
            type: 'line',
            data: {
                labels,
                datasets: numericCols.slice(0, 3).map((col, i) => ({
                    label: col,
                    data: rows.map(r => parseFloat(r[col]) || 0),
                    borderColor: palette[i], backgroundColor: palette[i] + '22',
                    tension: 0.4, fill: i === 0, pointRadius: rows.length > 30 ? 0 : 3
                }))
            },
            options: chartOptions('line', numericCols[0])
        }));
    } else if (lineEl && numericCols.length === 1) {
        const labels = rows.map((_, i) => textCols.length ? String(rows[i][textCols[0]]).slice(0, 12) : i + 1);
        chartInstances.push(new Chart(lineEl, {
            type: 'line',
            data: { labels, datasets: [{ label: numericCols[0], data: rows.map(r => parseFloat(r[numericCols[0]]) || 0), borderColor: palette[0], backgroundColor: palette[0] + '22', tension: 0.4, fill: true }] },
            options: chartOptions('line', numericCols[0])
        }));
    }

    // Pie chart — aggregate duplicates so each label appears only once
    const pieEl = document.getElementById(`chart-pie-${sanitizeId(key)}`);
    if (pieEl && textCols.length && numericCols.length) {
        // Group by the text column, summing the numeric column
        const grouped = {};
        rows.forEach(r => {
            const label = String(r[textCols[0]] ?? 'Unknown').slice(0, 22);
            const val = Math.abs(parseFloat(r[numericCols[0]]) || 0);
            grouped[label] = (grouped[label] || 0) + val;
        });
        // Sort by value desc, take top 8
        const sorted = Object.entries(grouped).sort((a,b) => b[1]-a[1]).slice(0, 8);
        const pieLabels = sorted.map(([k]) => k);
        const pieData = sorted.map(([,v]) => v);
        chartInstances.push(new Chart(pieEl, {
            type: 'doughnut',
            data: {
                labels: pieLabels,
                datasets: [{ data: pieData, backgroundColor: palette, borderColor: '#F5F0EB', borderWidth: 3, hoverBorderWidth: 4 }]
            },
            options: { ...chartOptions('pie'), cutout: '58%' }
        }));
    }

    // Scatter
    const scatterEl = document.getElementById(`chart-scatter-${sanitizeId(key)}`);
    if (scatterEl && numericCols.length >= 2) {
        chartInstances.push(new Chart(scatterEl, {
            type: 'scatter',
            data: { datasets: [{ label: `${numericCols[0]} vs ${numericCols[1]}`, data: rows.map(r => ({ x: parseFloat(r[numericCols[0]]) || 0, y: parseFloat(r[numericCols[1]]) || 0 })), backgroundColor: palette[0] + 'BB', pointRadius: 5 }] },
            options: chartOptions('scatter', numericCols[1])
        }));
    }

    tableCharts[key] = chartInstances;
}

function chartOptions(type, yLabel = '') {
    const base = {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: { labels: { color: '#5B2D9E', font: { family: 'Plus Jakarta Sans', size: 11 }, boxWidth: 12 } },
            tooltip: { backgroundColor: '#3B1F6E', titleColor: '#F5F0EB', bodyColor: '#C084FC', borderColor: '#7C3FCC', borderWidth: 1 }
        }
    };
    if (type === 'pie') return base;
    return {
        ...base,
        scales: {
            x: { grid: { color: 'rgba(155,93,229,0.08)' }, ticks: { color: '#9B87B8', font: { family: 'Plus Jakarta Sans', size: 10 }, maxRotation: 30, maxTicksLimit: 10 } },
            y: { grid: { color: 'rgba(155,93,229,0.08)' }, ticks: { color: '#9B87B8', font: { family: 'Plus Jakarta Sans', size: 10 } }, title: type !== 'scatter' ? { display: !!yLabel, text: yLabel, color: '#9B87B8' } : undefined }
        }
    };
}

function formatNum(n) {
    if (Math.abs(n) >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (Math.abs(n) >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    if (n % 1 !== 0) return n.toFixed(2);
    return n.toLocaleString();
}

// ===== DOWNLOAD =====
async function downloadTable(key) {
    const tables = currentResult?.tables;
    if (!tables || !tables[key]) { showToast('No data to download', 'error'); return; }
    const t = tables[key];
    try {
        const response = await fetch('/download', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ result_data: t.result_data, columns: t.columns, filename: key.replace(/\.\w+$/, '') + '_result.xlsx' })
        });
        if (!response.ok) throw new Error('Download failed');
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url;
        a.download = key.replace(/\.\w+$/, '') + '_analysis.xlsx';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast('Downloaded!', 'success');
    } catch (e) { showToast('Download failed: ' + e.message, 'error'); }
}

downloadBtn.addEventListener('click', () => {
    if (activeTableKey) downloadTable(activeTableKey);
    else showToast('No data to download', 'error');
});

// ===== TOAST =====
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const icons = { success: 'fa-circle-check', error: 'fa-circle-exclamation', info: 'fa-circle-info', warning: 'fa-triangle-exclamation' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i> ${message}`;
    container.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateX(30px)'; toast.style.transition = 'all 0.3s'; setTimeout(() => toast.remove(), 300); }, 4500);
}

// ===== KEYBOARD =====
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && document.activeElement === queryInput) sendQuery.click();
});
