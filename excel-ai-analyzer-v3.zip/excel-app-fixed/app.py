"""
Excel AI Analyzer - Flask Application
Upload multiple Excel files, query via voice or text using AI APIs
Supports: Gemini, Groq (free), OpenRouter (free), and local fallback
"""

from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
import os
import json
import tempfile
from werkzeug.utils import secure_filename
import re
import requests

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'uploads'

uploaded_data = {}
data_schema = {}

ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_data_summary(files_data):
    data_summary = []
    for filename, df in files_data.items():
        summary = f"\n=== FILE: {filename} ===\n"
        summary += f"Shape: {df.shape[0]} rows x {df.shape[1]} columns\n"
        summary += f"Columns: {', '.join(df.columns.tolist())}\n"
        summary += f"Data types: {dict(df.dtypes)}\n"
        summary += f"First 10 rows:\n{df.head(10).to_string()}\n"
        data_summary.append(summary)
    return "\n".join(data_summary)

def build_prompt(data_summary, query, file_list):
    files_json = json.dumps(file_list)
    return f"""You are an expert data analyst. Analyze the following Excel/CSV data and answer the user's query.

{data_summary}

USER QUERY: {query}

IMPORTANT INSTRUCTIONS:
1. Analyze the data carefully and provide accurate results.
2. You have these files: {files_json}
3. Return your response in the following JSON format ONLY — one entry per file that has relevant results:

{{
    "analysis_summary": "Brief summary of what was analyzed",
    "insights": "Key insights from the analysis",
    "tables": {{
        "<filename1>": {{
            "result_data": [
                {{"column1": "value1", "column2": "value2"}},
                ...
            ],
            "columns": ["column1", "column2", ...],
            "total_rows": <number>,
            "table_insight": "Insight specific to this table"
        }},
        "<filename2>": {{
            "result_data": [...],
            "columns": [...],
            "total_rows": <number>,
            "table_insight": "Insight specific to this table"
        }}
    }}
}}

4. The keys in "tables" MUST match the exact filenames from the uploaded files list.
5. Only include tables that have relevant results for the query.
6. If the query applies to all files, include all of them in tables.
7. Make sure column names in result_data match the columns array.
8. If the query asks for top N items, sort accordingly and return exactly N rows per relevant table.
9. Return ONLY the JSON, no markdown formatting, no explanation text.
10. Ensure the JSON is valid and properly formatted.
"""

def parse_ai_response(response_text):
    try:
        response_text = response_text.replace('```json', '').replace('```', '').strip()
        result = json.loads(response_text)
        return result
    except json.JSONDecodeError:
        try:
            start = response_text.find('{')
            end = response_text.rfind('}') + 1
            if start >= 0 and end > start:
                result = json.loads(response_text[start:end])
                return result
        except:
            pass
        return None

# ===== API 1: Google Gemini =====
def analyze_with_gemini(files_data, query, api_key):
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-2.0-flash')
        data_summary = get_data_summary(files_data)
        prompt = build_prompt(data_summary, query, list(files_data.keys()))
        response = model.generate_content(prompt)
        result = parse_ai_response(response.text)
        if result:
            return result
        return {"error": "Invalid response from Gemini", "api_used": "gemini"}
    except Exception as e:
        error_msg = str(e)
        if "quota" in error_msg.lower() or "429" in error_msg:
            return {"error": "Gemini quota exceeded", "api_used": "gemini", "fallback": True}
        return {"error": f"Gemini error: {error_msg}", "api_used": "gemini", "fallback": True}

# ===== API 2: Groq =====
def analyze_with_groq(files_data, query, api_key):
    try:
        data_summary = get_data_summary(files_data)
        prompt = build_prompt(data_summary, query, list(files_data.keys()))
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "llama-3.3-70b-versatile",
            "messages": [
                {"role": "system", "content": "You are a data analyst. Return only valid JSON."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.1,
            "max_tokens": 6000
        }
        response = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers=headers, json=payload, timeout=60
        )
        if response.status_code == 200:
            data = response.json()
            content = data['choices'][0]['message']['content']
            result = parse_ai_response(content)
            if result:
                result["api_used"] = "groq"
                return result
        elif response.status_code == 429:
            return {"error": "Groq rate limit", "api_used": "groq", "fallback": True}
        return {"error": f"Groq error: {response.status_code}", "api_used": "groq", "fallback": True}
    except Exception as e:
        return {"error": f"Groq error: {str(e)}", "api_used": "groq", "fallback": True}

# ===== API 3: OpenRouter =====
def analyze_with_openrouter(files_data, query, api_key):
    try:
        data_summary = get_data_summary(files_data)
        prompt = build_prompt(data_summary, query, list(files_data.keys()))
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:5000",
            "X-Title": "Excel AI Analyzer"
        }
        free_models = [
            "meta-llama/llama-3.1-70b-instruct:free",
            "google/gemma-2-9b-it:free",
            "nousresearch/hermes-3-llama-3.1-405b:free"
        ]
        for model in free_models:
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": "You are a data analyst. Return only valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.1,
                "max_tokens": 6000
            }
            response = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers=headers, json=payload, timeout=60
            )
            if response.status_code == 200:
                data = response.json()
                if 'choices' in data and len(data['choices']) > 0:
                    content = data['choices'][0]['message']['content']
                    result = parse_ai_response(content)
                    if result:
                        result["api_used"] = f"openrouter ({model.split('/')[1].split(':')[0]})"
                        return result
            elif response.status_code == 429:
                continue
        return {"error": "OpenRouter free models unavailable", "api_used": "openrouter", "fallback": True}
    except Exception as e:
        return {"error": f"OpenRouter error: {str(e)}", "api_used": "openrouter", "fallback": True}

# ===== LOCAL FALLBACK =====
def process_locally(files_data, query):
    query_lower = query.lower()
    num_match = re.search(r'top\s+(\d+)', query_lower)
    top_n = int(num_match.group(1)) if num_match else 10

    tables = {}
    for filename, df in files_data.items():
        all_cols = df.columns.tolist()
        result_data = []
        columns = []
        table_insight = ""

        try:
            if 'where' in query_lower or 'filter' in query_lower:
                for col in all_cols:
                    col_lower = col.lower()
                    if col_lower in query_lower:
                        idx = query_lower.find(col_lower)
                        rest = query_lower[idx + len(col_lower):]
                        words = rest.replace('is', '').replace('=', '').strip().split()
                        if words:
                            filter_val = words[0].strip()
                            try:
                                result_df = df[df[col].astype(str).str.lower().str.contains(filter_val, na=False)]
                                table_insight = f"Found {len(result_df)} matching records where {col} contains '{filter_val}'"
                                result_data = result_df.head(50).to_dict('records')
                                columns = result_df.columns.tolist()
                                break
                            except:
                                pass

            if not result_data:
                numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
                if numeric_cols:
                    sort_col = None
                    for col in numeric_cols:
                        col_lower = col.lower()
                        if any(word in query_lower for word in ['sales', 'revenue', 'amount', 'total', 'spend', 'price', 'cost']):
                            if any(word in col_lower for word in ['sales', 'revenue', 'amount', 'total', 'spend', 'price', 'cost']):
                                sort_col = col
                                break
                    if not sort_col:
                        sort_col = numeric_cols[0]
                    result_df = df.nlargest(top_n, sort_col)
                    table_insight = f"Top {top_n} by {sort_col} from {len(df)} records"
                    result_data = result_df.to_dict('records')
                    columns = result_df.columns.tolist()
                else:
                    result_df = df.head(top_n)
                    table_insight = f"First {top_n} rows from {len(df)} total records"
                    result_data = result_df.to_dict('records')
                    columns = result_df.columns.tolist()
        except Exception as e:
            result_df = df.head(20)
            table_insight = f"Sample data (local processing)"
            result_data = result_df.to_dict('records')
            columns = result_df.columns.tolist()

        tables[filename] = {
            "result_data": result_data,
            "columns": columns,
            "total_rows": len(result_data),
            "table_insight": table_insight
        }

    return {
        "analysis_summary": "Processed using local engine",
        "insights": "Using local pandas processing — configure an AI API for smarter analysis",
        "tables": tables,
        "api_used": "local (pandas)",
        "fallback_notice": "All AI APIs unavailable. Using local processing."
    }

# ===== MAIN ANALYZE FUNCTION =====
def analyze_data(files_data, query, api_configs):
    errors = []

    if api_configs.get('gemini_key'):
        result = analyze_with_gemini(files_data, query, api_configs['gemini_key'])
        if 'error' not in result or not result.get('fallback'):
            return result
        errors.append(f"Gemini: {result.get('error')}")

    if api_configs.get('groq_key'):
        result = analyze_with_groq(files_data, query, api_configs['groq_key'])
        if 'error' not in result or not result.get('fallback'):
            return result
        errors.append(f"Groq: {result.get('error')}")

    if api_configs.get('openrouter_key'):
        result = analyze_with_openrouter(files_data, query, api_configs['openrouter_key'])
        if 'error' not in result or not result.get('fallback'):
            return result
        errors.append(f"OpenRouter: {result.get('error')}")

    result = process_locally(files_data, query)
    result['api_errors'] = errors
    return result

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    global uploaded_data, data_schema
    try:
        if 'files' not in request.files:
            return jsonify({'error': 'No files provided'}), 400
        files = request.files.getlist('files')
        uploaded_data = {}
        data_schema = {}
        uploaded_count = 0
        errors = []
        for file in files:
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                temp_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(temp_path)
                try:
                    if filename.endswith('.csv'):
                        df = pd.read_csv(temp_path)
                    else:
                        df = pd.read_excel(temp_path)
                    uploaded_data[filename] = df
                    data_schema[filename] = {
                        'columns': df.columns.tolist(),
                        'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
                        'shape': df.shape,
                        'sample': df.head(3).to_dict('records')
                    }
                    uploaded_count += 1
                    os.remove(temp_path)
                except Exception as e:
                    errors.append(f'{filename}: {str(e)}')
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
        if uploaded_count == 0 and errors:
            return jsonify({'error': f'Failed to read files: {"; ".join(errors)}'}), 400
        return jsonify({
            'success': True,
            'message': f'{uploaded_count} file(s) uploaded successfully',
            'files': list(uploaded_data.keys()),
            'schema': data_schema,
            'errors': errors if errors else None
        })
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/analyze', methods=['POST'])
def analyze():
    try:
        data = request.get_json(force=True)
        if not data:
            return jsonify({'error': 'Invalid JSON data'}), 400
        query = data.get('query', '')
        api_configs = {
            'gemini_key': data.get('gemini_key', ''),
            'groq_key': data.get('groq_key', ''),
            'openrouter_key': data.get('openrouter_key', ''),
        }
        if not uploaded_data:
            return jsonify({'error': 'No files uploaded'}), 400
        if not query:
            return jsonify({'error': 'No query provided'}), 400
        result = analyze_data(uploaded_data, query, api_configs)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/download', methods=['POST'])
def download():
    try:
        data = request.get_json(force=True)
        if not data:
            return jsonify({'error': 'Invalid JSON data'}), 400
        result_data = data.get('result_data', [])
        columns = data.get('columns', [])
        filename = data.get('filename', 'analysis_result.xlsx')
        if not result_data:
            return jsonify({'error': 'No data to download'}), 400
        df = pd.DataFrame(result_data)
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
        df.to_excel(temp_file.name, index=False, engine='openpyxl')
        temp_file.close()
        return send_file(
            temp_file.name,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        return jsonify({'error': f'Download failed: {str(e)}'}), 500

@app.route('/preview', methods=['POST'])
def preview():
    try:
        data = request.get_json(force=True)
        if not data:
            return jsonify({'error': 'Invalid JSON data'}), 400
        filename = data.get('filename', '')
        if filename not in uploaded_data:
            return jsonify({'error': 'File not found'}), 404
        df = uploaded_data[filename]
        return jsonify({
            'columns': df.columns.tolist(),
            'preview': df.head(20).to_dict('records'),
            'shape': df.shape,
            'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()}
        })
    except Exception as e:
        return jsonify({'error': f'Preview failed: {str(e)}'}), 500

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True, host='0.0.0.0', port=5000)
